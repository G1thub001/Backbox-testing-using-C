
//mapper_child.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

#define MAXLINESIZE 1024
#define MAXWORDSIZE 256
#define MAX_THREADS 100

// Define your struct for map item
struct MapItem {
    char word[MAXWORDSIZE];
    int count;
};

// Define your bounded buffer struct
struct BoundedBuffer {
    struct MapItem items[MAXLINESIZE];
    int front, rear, itemCount;
    pthread_mutex_t mutex;
    pthread_cond_t empty, full;
};

// Function prototypes
void* worker_thread(void* arg);
void* sender_thread(void* arg);
void insert_item(struct MapItem item);
struct MapItem remove_item();

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s directoryPath\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Parse command line argument
    char *directoryPath = argv[1];

    // Create threads for worker and sender
    pthread_t workerThreads[MAX_THREADS], senderThread;
    pthread_create(&senderThread, NULL, sender_thread, NULL);

    // Open directory
    DIR *dir = opendir(directoryPath);
    if (dir == NULL) {
        perror("opendir");
        exit(EXIT_FAILURE);
    }

    // Read directory
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        // Skip directories
        if (entry->d_type == DT_DIR)
            continue;

        // Construct file path
        char filePath[MAXLINESIZE];
        sprintf(filePath, "%s/%s", directoryPath, entry->d_name);

        // Create and run worker thread for each file
        pthread_t thread;
        pthread_create(&thread, NULL, worker_thread, filePath);
        workerThreads[threadCount++] = thread;
    }

    // Join worker threads
    for (int i = 0; i < threadCount; i++) {
        pthread_join(workerThreads[i], NULL);
    }

    // Close directory
    closedir(dir);

    // Wait for sender thread to finish
    pthread_join(senderThread, NULL);

    return 0;
}

void* worker_thread(void* arg) {
    char *filePath = (char*) arg;

    // Open file
    FILE *file = fopen(filePath, "r");
    if (file == NULL) {
        perror("fopen");
        pthread_exit(NULL);
    }

    // Read words from file and create map items
    char word[MAXWORDSIZE];
    while (fscanf(file, "%s", word) == 1) {
        struct MapItem item;
        strcpy(item.word, word);
        item.count = 1;
        insert_item(item);
    }

    // Close file
    fclose(file);

    pthread_exit(NULL);
}

void* sender_thread(void* arg) {
    // Implement sender thread logic to retrieve items from bounded buffer and send to reducer
    while (1) {
        // Retrieve items from bounded buffer
        struct MapItem item = remove_item();
        // Send items to reducer
        // Note: We don't need to send items from child processes to the reducer,
        // as they will be sent from the parent process.
    }
    pthread_exit(NULL);
}

void insert_item(struct MapItem item) {
    // Implement logic to insert item into bounded buffer
}

struct MapItem remove_item() {
    // Implement logic to remove item from bounded buffer
    struct MapItem item;
    return item;
}
