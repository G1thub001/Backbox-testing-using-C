#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h> 
#include <dirent.h>    

#define MAXLINESIZE 1024
#define MAXWORDSIZE 256
#define MAX_THREADS 100

// Define your struct for map item
struct MapItem {
    char word[MAXWORDSIZE];
    int count;
};

// Define your bounded buffer struct
struct BoundedBuffer {
    struct MapItem items[MAXLINESIZE];
    int front, rear, itemCount;
    sem_t mutex, empty, full;
};

// Global variables
struct BoundedBuffer buffer;
int bufferSize;
key_t key;
int msqid;

// Function prototypes
void* worker_thread(void* arg);
void* sender_thread(void* arg);
void insert_item(struct MapItem item);
struct MapItem remove_item();

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s commandFile bufferSize\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Parse command line arguments
    char *commandFile = argv[1];
    bufferSize = atoi(argv[2]);

    // Initialize bounded buffer and semaphores
    buffer.front = buffer.rear = buffer.itemCount = 0;
    sem_init(&buffer.mutex, 0, 1);
    sem_init(&buffer.empty, 0, bufferSize);
    sem_init(&buffer.full, 0, 0);

    // Create message queue key
    key = ftok("mapper.c", 1);
    if (key == -1) {
        perror("ftok");
        exit(EXIT_FAILURE);
    }

    // Create or get message queue
    msqid = msgget(key, IPC_CREAT | 0666);
    if (msqid == -1) {
        perror("msgget");
        exit(EXIT_FAILURE);
    }

    // Open command file
    FILE *fp = fopen(commandFile, "r");
    if (fp == NULL) {
        perror("fopen");
        exit(EXIT_FAILURE);
    }

    // Read command file line by line
    char line[MAXLINESIZE];
    while (fgets(line, MAXLINESIZE, fp) != NULL) {
        line[strcspn(line, "\n")] = 0; // Remove trailing newline character
        pid_t pid = fork();
        if (pid == -1) {
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (pid == 0) {
            // Child process
            char *args[] = {"./mapper_child", line, NULL};
            execvp(args[0], args);
            perror("execvp");
            exit(EXIT_FAILURE);
        }
    }

    // Close file
    fclose(fp);

    // Wait for all child processes to finish
    int status;
    while (wait(&status) > 0);

    // Close message queue
    if (msgctl(msqid, IPC_RMID, NULL) == -1) {
        perror("msgctl");
        exit(EXIT_FAILURE);
    }

    return 0;
}

void* worker_thread(void* arg) {
    char *directoryPath = (char*) arg;

    // Open directory
    DIR *dir = opendir(directoryPath);
    if (dir == NULL) {
        perror("opendir");
        exit(EXIT_FAILURE);
    }

    // Read directory
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        // Skip directories
        if (entry->d_type == DT_DIR)
            continue;

        // Construct file path
        char filePath[MAXLINESIZE];
        sprintf(filePath, "%s/%s", directoryPath, entry->d_name);

        // Open file
        FILE *file = fopen(filePath, "r");
        if (file == NULL) {
            perror("fopen");
            continue;
        }

        // Read words from file and create map items
        char word[MAXWORDSIZE];
        while (fscanf(file, "%s", word) == 1) {
            struct MapItem item;
            strcpy(item.word, word);
            item.count = 1;
            insert_item(item);
        }

        // Close file
        fclose(file);
    }

    // Close directory
    closedir(dir);

    return NULL;
}

void* sender_thread(void* arg) {
    while (1) {
        // Retrieve items from bounded buffer
        struct MapItem item = remove_item();

        // Send items to reducer through message queue
        if (msgsnd(msqid, &item, sizeof(struct MapItem), 0) == -1) {
            perror("msgsnd");
            exit(EXIT_FAILURE);
        }
    }
    return NULL;
}

void insert_item(struct MapItem item) {
    sem_wait(&buffer.empty);
    sem_wait(&buffer.mutex);
    buffer.items[buffer.rear] = item;
    buffer.rear = (buffer.rear + 1) % MAXLINESIZE;
    buffer.itemCount++;
    sem_post(&buffer.mutex);
    sem_post(&buffer.full);
}

struct MapItem remove_item() {
    struct MapItem item;
    sem_wait(&buffer.full);
    sem_wait(&buffer.mutex);
    item = buffer.items[buffer.front];
    buffer.front = (buffer.front + 1) % MAXLINESIZE;
    buffer.itemCount--;
    sem_post(&buffer.mutex);
    sem_post(&buffer.empty);
    return item;
}
