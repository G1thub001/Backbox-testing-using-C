
//reducer.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define MAXWORDSIZE 256

// Define your struct for map item
struct MapItem {
    char word[MAXWORDSIZE];
    int count;
};

// Function prototypes
void process_map_items(int msqid, FILE *outputFile, int minFrequency);

int main(int argc, char *argv[]) {
    if (argc != 4) {
        fprintf(stderr, "Usage: %s outputFile minFrequency\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Parse command line arguments
    char *outputFile = argv[1];
    int minFrequency = atoi(argv[2]);

    // Get message queue identifier using ftok
    key_t key = ftok("mapper.c", 1);
    if (key == -1) {
        perror("ftok");
        exit(EXIT_FAILURE);
    }

    // Get message queue
    int msqid = msgget(key, 0666);
    if (msqid == -1) {
        perror("msgget");
        exit(EXIT_FAILURE);
    }

    // Open output file
    FILE *outfp = fopen(outputFile, "w");
    if (outfp == NULL) {
        perror("fopen");
        exit(EXIT_FAILURE);
    }

    // Process map items received from mapper
    process_map_items(msqid, outfp, minFrequency);

    // Close output file
    fclose(outfp);

    return 0;
}


void process_map_items(int msqid, FILE *outputFile, int minFrequency) {
    struct MapItem item;
    struct MapItem aggregatedItems[MAXWORDSIZE]; // Array to store aggregated items
    int numAggregatedItems = 0;

    // Initialize aggregatedItems array
    for (int i = 0; i < MAXWORDSIZE; i++) {
        strcpy(aggregatedItems[i].word, "");
        aggregatedItems[i].count = 0;
    }

    // Receive map items from mapper
    while (msgrcv(msqid, &item, sizeof(struct MapItem), 0, 0) != -1) {
        // Check if the word already exists in the aggregatedItems array
        int found = 0;
        for (int i = 0; i < numAggregatedItems; i++) {
            if (strcmp(aggregatedItems[i].word, item.word) == 0) {
                // Word found, update its count
                aggregatedItems[i].count += item.count;
                found = 1;
                break;
            }
        }
        // If the word is not found, add it to the aggregatedItems array
        if (!found) {
            strcpy(aggregatedItems[numAggregatedItems].word, item.word);
            aggregatedItems[numAggregatedItems].count = item.count;
            numAggregatedItems++;
        }
    }

    // Write aggregated results to the output file
    for (int i = 0; i < numAggregatedItems; i++) {
        if (aggregatedItems[i].count >= minFrequency) {
            fprintf(outputFile, "%s %d\n", aggregatedItems[i].word, aggregatedItems[i].count);
        }
    }
}
